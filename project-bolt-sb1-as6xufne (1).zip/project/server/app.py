from flask import Flask, jsonify, request
from flask_cors import CORS
import pymysql
import os
from dotenv import load_dotenv
import jwt
from datetime import datetime, timedelta
from functools import wraps

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

# Database connection
def get_db():
    return pymysql.connect(
        host=os.getenv('DB_HOST'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD'),
        db=os.getenv('DB_NAME'),
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

# JWT verification decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'error': 'Unauthorized', 'message': 'Token is missing'}), 401

        try:
            jwt.decode(token, os.getenv('JWT_SECRET'), algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Unauthorized', 'message': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Unauthorized', 'message': 'Invalid token'}), 401

        return f(*args, **kwargs)
    return decorated

# Login attempts tracking
login_attempts = {}

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    ip = request.remote_addr

    # Check login attempts
    if ip in login_attempts:
        attempts = login_attempts[ip]
        if attempts['count'] >= 5:
            time_passed = datetime.now() - attempts['timestamp']
            if time_passed < timedelta(hours=24):
                return jsonify({
                    'error': 'Too many login attempts',
                    'message': 'Please try again after 24 hours'
                }), 429
            else:
                login_attempts[ip] = {'count': 0, 'timestamp': datetime.now()}

    if email == os.getenv('ADMIN_EMAIL') and password == os.getenv('ADMIN_PASSWORD'):
        if ip in login_attempts:
            del login_attempts[ip]
        
        token = jwt.encode(
            {'email': email, 'exp': datetime.utcnow() + timedelta(hours=24)},
            os.getenv('JWT_SECRET'),
            algorithm='HS256'
        )
        
        return jsonify({'token': token})
    else:
        if ip not in login_attempts:
            login_attempts[ip] = {'count': 1, 'timestamp': datetime.now()}
        else:
            login_attempts[ip]['count'] += 1
        
        return jsonify({
            'error': 'Authentication failed',
            'message': 'Invalid email or password',
            'attemptsLeft': 5 - login_attempts[ip]['count']
        }), 401

@app.route('/api/systems', methods=['GET'])
@token_required
def get_systems():
    try:
        db = get_db()
        with db.cursor() as cursor:
            cursor.execute('SELECT id, topic FROM systems ORDER BY topic ASC')
            systems = cursor.fetchall()
        db.close()
        return jsonify(systems)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/questions', methods=['GET'])
@token_required
def get_questions():
    try:
        system_id = request.args.get('systemId')
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 50))
        offset = (page - 1) * limit

        db = get_db()
        with db.cursor() as cursor:
            query = '''
                SELECT q.id, q.already_updated
                FROM questions_duplicated q
                JOIN subtopic_lists s ON q.subtopic_list_id = s.id
                JOIN topic_lists t ON s.topic_id = t.id
                WHERE t.system_id = %s
                ORDER BY q.id ASC
                LIMIT %s OFFSET %s
            '''
            cursor.execute(query, (system_id, limit, offset))
            questions = cursor.fetchall()
        db.close()
        return jsonify(questions)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/questions/<int:id>', methods=['GET'])
@token_required
def get_question(id):
    try:
        db = get_db()
        with db.cursor() as cursor:
            cursor.execute('SELECT * FROM questions_duplicated WHERE id = %s', (id,))
            question = cursor.fetchone()
            if not question:
                return jsonify({
                    'error': 'Question not found',
                    'message': f'No question found with ID {id}'
                }), 404
        db.close()
        return jsonify(question)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/progress', methods=['GET'])
@token_required
def get_progress():
    try:
        db = get_db()
        with db.cursor() as cursor:
            cursor.execute('SELECT COUNT(*) as total FROM questions_duplicated')
            total = cursor.fetchone()['total']
            
            cursor.execute('SELECT COUNT(*) as updated FROM questions_duplicated WHERE already_updated = TRUE')
            updated = cursor.fetchone()['updated']
        db.close()
        
        return jsonify({
            'totalCount': total,
            'updatedCount': updated
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(port=3001, debug=True)