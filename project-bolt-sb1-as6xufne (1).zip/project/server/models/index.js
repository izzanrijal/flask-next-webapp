import { DataTypes } from 'sequelize';

export default function initModels(sequelize) {
  // Define models
  const System = sequelize.define('System', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    topic: {
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    tableName: 'systems',
    timestamps: false
  });

  const TopicList = sequelize.define('TopicList', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    system_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'systems',
        key: 'id'
      }
    }
  }, {
    tableName: 'topic_lists',
    timestamps: false
  });

  const SubtopicList = sequelize.define('SubtopicList', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    topic_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'topic_lists',
        key: 'id'
      }
    }
  }, {
    tableName: 'subtopic_lists',
    timestamps: false
  });

  const Question = sequelize.define('Question', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    subtopic_list_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'subtopic_lists',
        key: 'id'
      }
    },
    scenario: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    image_url: {
      type: DataTypes.STRING
    },
    question: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    option_a: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    option_b: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    option_c: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    option_d: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    option_e: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    correct_answer: {
      type: DataTypes.CHAR(1),
      allowNull: false,
      validate: {
        isIn: [['A', 'B', 'C', 'D', 'E']]
      }
    },
    discussion: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    learning_objective: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    already_updated: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false
    }
  }, {
    tableName: 'questions_duplicated',
    timestamps: false
  });

  // Define associations
  System.hasMany(TopicList, { foreignKey: 'system_id' });
  TopicList.belongsTo(System, { foreignKey: 'system_id' });

  TopicList.hasMany(SubtopicList, { foreignKey: 'topic_id' });
  SubtopicList.belongsTo(TopicList, { foreignKey: 'topic_id' });

  SubtopicList.hasMany(Question, { foreignKey: 'subtopic_list_id' });
  Question.belongsTo(SubtopicList, { foreignKey: 'subtopic_list_id' });

  return {
    System,
    TopicList,
    SubtopicList,
    Question
  };
}